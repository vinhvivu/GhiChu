﻿namespace TrackPlayer.Players
{

    class CastPlayback {

        // TODO
        // https://github.com/Tapanila/SharpCaster
        // https://docs.microsoft.com/windows/uwp/audio-video-camera/media-casting

    }
}
