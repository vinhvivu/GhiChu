# Configuration

Run `react-native info` in your project and share the content.
What `react-native-track-player` version are you using?

# Issue
<!--
  Please, describe with details the problem, let us know which platform (Android, iOS or Windows) and which OS version are you experiencing this issue.
  Crash logs, step-by-step instructions, code snippets and device details may also help us identify and reproduce the issue.
-->

# Code

Show us the code you are using
